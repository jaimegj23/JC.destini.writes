export default function JCDestiniAuthorSite() {
  return (
    <main className="min-h-screen bg-black text-white p-10 font-sans">
      <h1 className="text-4xl font-bold text-center">J.C. Destini</h1>
      <p className="text-center text-purple-300 mt-2">Ink by Fire. Words That Heal.</p>
      <p className="mt-6 max-w-2xl mx-auto text-lg text-gray-200">
        Welcome to my official author site. I write what I survived—memoirs, poetry, and powerful reflections.
        Stay tuned for book releases, blog updates, and more.
      </p>
    </main>
  );
}
